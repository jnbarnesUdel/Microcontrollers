/*===================================CPEG222=================================
* Program: HW1
* Authors: Jonathan Barnes, Joshua Chevalier
* Team #:37
* Date: 9/13/2017
* Description: This is a program that lights up led's sequentially with 1 second delays
=============================================================================*/
#include <xc.h>
#include <plib.h>

void delay_ms(int ms){
    int i,counter;
    for (counter=0; counter< ms; counter ++){
        for(i =0;i<70;i++){}   //software delay 1
       }
}

int main(void) {
    DDPCONbits.JTAGEN = 0;     // Statement is required to use Pin RA0 as IO
    TRISA = 0x0;                // set PORTA pins (LEDs) as outputs(0)
    ANSELA = 0x0;               // set PORTA as digital IO not analog
    LATA = 0x0;                 // turn off 
    ANSELF = 0x0;               // set PORTF as digital IO
    while (1) {
        int i;
        for(i = 0; i<=7; i++)
        {
            if(i==0)
            {
                LATAbits.LATA0 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA0 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==1)
            {
                LATAbits.LATA1 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA1 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==2)
            {
                LATAbits.LATA2 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA2 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==3)
            {
                LATAbits.LATA3 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA3 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==4)
            {
                LATAbits.LATA4 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA4 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==5)
            {
                LATAbits.LATA5 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA5 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==6)
            {
                LATAbits.LATA6 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA6 = 0; //turn off led 0
                delay_ms(1000);
                
            }
            else if(i==7)
            {
                LATAbits.LATA7 = 1; //turn on led 0
                delay_ms(1000);
                LATAbits.LATA7  = 0; //turn off led 0
                delay_ms(1000);
                
            }
        }
       }
}

